package org.example.backend.dto;

public record LoginRequest(String username, String password) {
    // Constructor
}