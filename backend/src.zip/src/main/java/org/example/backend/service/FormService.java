package org.example.backend.service;

import org.example.backend.model.Form;
import org.example.backend.model.Page;
import org.example.backend.model.Question;
import org.example.backend.model.User;
import org.example.backend.repository.FormRepository;
import org.example.backend.repository.PageRepository;
import org.example.backend.repository.QuestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class FormService {

    private final FormRepository formRepository;
    private final PageRepository pageRepository;
    private final QuestionRepository questionRepository;

    @Autowired
    public FormService(FormRepository formRepository,
                       PageRepository pageRepository,
                       QuestionRepository questionRepository) {
        this.formRepository = formRepository;
        this.questionRepository = questionRepository;
        this.pageRepository = pageRepository;
    }

    public Form createForm(Form form) {
        // Save the form entity to the database
        // Save each question associated with the form
        List<Page> pages = form.getPages();
        Form createdForm = new Form();

        try {
            Form newForm = new Form();
            newForm.setOwner(form.getOwner());
            newForm.setTitle(form.getTitle());
            newForm.setDescription(form.getDescription());
            newForm.setId(form.getId());
            createdForm = formRepository.save(newForm);
        } catch (Exception e) {
            e.printStackTrace();
        }

        List<Page> savedPages = new ArrayList<Page>();
        for (Page page : pages) {
            Page createdPage = new Page();
            createdPage.setForm(createdForm);
            createdPage.setPageIndex(page.getPageIndex());
            Page p = pageRepository.save(createdPage);
            List<Question> savedQuestions = new ArrayList<Question>();
            for (Question question: page.getQuestions()){
                question.setPage(createdPage);
                Question q = questionRepository.save(question);
                savedQuestions.add(q);
            }
            p.setQuestions(savedQuestions);
            savedPages.add(p);
        }


        createdForm.setPages(savedPages);

        return createdForm;
    }

    public Form getFormById(Long id) {
        // Use Optional to handle the possible absence of the form
        Optional<Form> formOptional = formRepository.findById(id);

        // If the form is present, return it, otherwise return null or throw an exception
        return formOptional.orElse(null); // or you can throw an exception if the form is not found
    }

    public List<Form> getAllFormsByOwner(User owner) {
        return this.formRepository.getFormsByOwner(owner);
    }
}
