package org.example.backend.dto;

public record LoginResponse(String token) {
}
