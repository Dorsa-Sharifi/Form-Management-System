package org.example.backend.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Page {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int pageIndex;

    @ManyToOne
    @JoinColumn(name = "form_id")
    @JsonIgnore
    private Form form;

    @OneToMany(mappedBy = "page", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Question> questions = new ArrayList<Question>();

    public Page() {}

    public void setForm(Form form) {
        this.form = form;
    }

    public Form getForm(Form form) {
        return this.form;
    }

    public List<Question> getQuestions() {
        return questions;
    }

    public void setQuestions(List<Question> questions) {
        this.questions.clear();
        this.questions.addAll(questions);
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }
    public int getPageIndex() {
        return pageIndex;
    }
}
