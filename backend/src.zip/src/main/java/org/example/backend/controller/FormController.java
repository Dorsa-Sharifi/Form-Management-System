package org.example.backend.controller;

import org.example.backend.model.CustomUserDetail;
import org.example.backend.model.Form;
import org.example.backend.model.Question;
import org.example.backend.model.User;
import org.example.backend.service.FormDataService;
import org.example.backend.service.FormService;
import org.example.backend.service.QueryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.example.backend.dto.ReportRequest;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class FormController {

    private final FormService formService;
    private final FormDataService  formDataService;

    private final QueryService queryService;

    @Autowired
    public FormController(FormService formService, FormDataService formDataService , QueryService queryService) {
        this.formService = formService;
        this.formDataService = formDataService;
        this.queryService = queryService ;
    }

    @PostMapping("/form")
    public ResponseEntity<Form> createForm(@RequestBody Form newForm,
                                           @AuthenticationPrincipal CustomUserDetail userDetails) {
        User user = userDetails.getUser();
        newForm.setOwner(user);

        Form createdForm = formService.createForm(newForm);

        formDataService.createFormTable(newForm);


        return ResponseEntity.ok(createdForm);
    }

    @GetMapping("/forms")
    public ResponseEntity<List<Form>> getAllForms(@AuthenticationPrincipal CustomUserDetail userDetails) {
        User user = userDetails.getUser(); // get the full authenticated user

        List<Form> forms = this.formService.getAllFormsByOwner(user); // query forms for this user

        return ResponseEntity.ok(forms);
    }


    @GetMapping("/form/{formId}")
    public ResponseEntity<Form> getFormById(@PathVariable Long formId) {
        Form form = formService.getFormById(formId);

        if (form == null) {
            return ResponseEntity.notFound().build(); // Return 404 if the form is not found
        }

        return ResponseEntity.ok(form); // Return the form in the response body
    }

    @GetMapping("/form/{formId}/results")
    public ResponseEntity<List<Map<String, Object>>> getFormResultsById(@PathVariable Long formId) {
        Form form = formService.getFormById(formId);

        if (form == null) {
            return ResponseEntity.notFound().build(); // Return 404 if the form is not found
        }

        return ResponseEntity.ok(formDataService.getFormData(formId));
    }

    // Endpoint to submit form data (e.g., POST /api/form/{form_id}/submit)
    @PostMapping("/form/{formId}/submit")
    public ResponseEntity<String> submitFormData(@PathVariable Long formId, @RequestBody Map<String, Object> formData) {
        System.out.println("Received form data for form ID: " + formId);
        // Insert form data into the dynamic table
        formDataService.insertFormData(formId, formData);
        return ResponseEntity.ok("Form data submitted successfully!");
    }

    @GetMapping("/form/{formId}/fields")
    public ResponseEntity<List<Map<String, Object>>> getFormFields(@PathVariable Long formId) {
        Form form = formService.getFormById(formId);
        if (form == null) {
            return ResponseEntity.notFound().build(); // Return 404 if the form is not found
        }
        return ResponseEntity.ok(formDataService.getFormFields(formId)); // Return the list of questions in the response body
    }

    @PostMapping("/form/{formId}/query")
    public ResponseEntity<List<Map<String, Object>>> runAggregatedQuery(
            @PathVariable Long formId,
            @RequestBody ReportRequest request) {
        List<Map<String, Object>> results = queryService.runAggregatedQuery(
                formId,
                request.groupBy(),
                request.target(),
                request.func(),
                request.chartType()
        );
        return ResponseEntity.ok(results);
    }

}
