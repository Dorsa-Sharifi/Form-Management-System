package org.example.backend.model;

import javax.persistence.*;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;


@Entity
public class Question {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    private Long id;

    @JsonProperty("que")
    private String text;
    private String type;  // e.g., "text", "multiple-choice", etc.
    private String dataType;
    private boolean optional;

    @ElementCollection
    private List<String> choices;  // Can be null if not needed for certain types of questions

    @ManyToOne
    @JoinColumn(name = "page_id", nullable = false)
    @JsonIgnore
    private Page page;

    // Constructor
    public Question(String text, String type, List<String> choices) {
        this.text = text;
        this.type = type;
        this.choices = choices;
    }

    public Question() {

    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getChoices() {
        return choices;
    }

    public void setChoices(List<String> choices) {
        this.choices = choices;
    }

    public Page getPage() {
        return this.page;
    }

    public void setPage(Page page) {
        this.page = page;
    }

    public void setOptional(boolean optional) {
        this.optional = optional;
    }

    public boolean getOptional() {
        return optional;
    }

    public void  setDataType(String dataType) {
        this.dataType = dataType;
    }
    public String getDataType() {
        return dataType;
    }
}
