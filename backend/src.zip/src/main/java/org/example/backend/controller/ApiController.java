package org.example.backend.controller;

import org.example.backend.model.CustomUserDetail;
import org.example.backend.model.User;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.example.backend.dto.*;

@RestController
@RequestMapping("/api")
public class ApiController {

    @GetMapping("/hello")
    public ResponseEntity<String> sayHello() {
        return ResponseEntity.ok("Hello from Spring Boot!");
    }

    @PostMapping("/echo")
    public ResponseEntity<String> echo(@RequestBody String message) {
        return ResponseEntity.ok("Echo: " + message);
    }

    @PostMapping("/me")
    public ResponseEntity<User> me(@AuthenticationPrincipal CustomUserDetail userDetails) {
        return ResponseEntity.ok(userDetails.getUser());
    }
}
