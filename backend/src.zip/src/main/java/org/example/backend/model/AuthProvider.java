package org.example.backend.model;

public enum AuthProvider {
    LOCAL, GOOGLE
}
