package org.example.backend.model;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.example.backend.model.AuthProvider;
import java.util.Set;

@Entity
@Table(name = "users",
        uniqueConstraints = @UniqueConstraint(columnNames = "username"))
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    private Long id;

    @Column(nullable = false)
    private String username;

    @Column(nullable = false)
    @JsonIgnore
    private String password;

    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    private AuthProvider provider;      // LOCAL or GOOGLE
    private String providerId;          // Google "sub" value

    @Column(nullable = false)
    private Role role;

    public User() { }

    public User(String username, String password, Role role, String name) {
        this.username = username;
        this.password = password;
        this.role = role;
        this.name = name;
        this.provider = AuthProvider.LOCAL;
    }

    public User(String sub, String name) {
        this.username = sub;
        this.name = name;
        this.provider = AuthProvider.GOOGLE;
    }

    // —— Getters & setters —— //

    public Long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }

    public AuthProvider getProvider() {
        return provider;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public Role getRole() {
        return role;
    }
    public void setRole(Role role) {
        this.role = role;
    }

    public void setProvider(AuthProvider authProvider) {
        this.provider = authProvider;
    }

    public void setName(String name) {
        this.name = name;
    }
}
