

package org.example.backend.service;
import org.example.backend.model.Form;
import org.example.backend.model.Page;
import org.example.backend.model.Question;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@Service
public class FormDataService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void createFormTable(Form form) {
        StringBuilder sql = new StringBuilder("CREATE TABLE form_")
                .append(form.getId())
                .append(" (id SERIAL PRIMARY KEY, user_id INTEGER");

        // Dynamically add columns for each question in the form
        for (Page page: form.getPages()) {
            for (Question question : page.getQuestions()) {
                sql.append(", question_").append(question.getId()).append(" ")
                        .append(getColumnType(question));  // You will need to define getColumnType based on question type
            }
        }

        sql.append(");");

        // Execute the dynamically generated SQL
        jdbcTemplate.execute(sql.toString());
    }

    private String getColumnType(Question question) {
        // Return the correct column type based on the question type (e.g., VARCHAR, INTEGER)
        return switch (question.getDataType().toUpperCase()) {
            case "LONG_TEXT" -> "TEXT" ;
            case "NUMBER" -> "INTEGER";
            case "BOOL" -> "BOOLEAN";
            default -> "VARCHAR(255)";
        };
    }

    // Method for inserting form data into the dynamic table
    public void insertFormData(Long formId, Map<String, Object> formData) {
        StringBuilder sql = new StringBuilder("INSERT INTO form_")
                .append(formId)
                .append(" (user_id");

        StringBuilder values = new StringBuilder(") VALUES (");

        // Dynamically add columns and values for each question
        values.append(" ?");  // Placeholder for user ID
        for (Map.Entry<String, Object> entry : formData.entrySet()) {
            sql.append(", ").append(entry.getKey());  // Add column name
            values.append(", ?");  // Placeholder for value
        }

        sql.append(values.toString()).append(");");

        //make a new array containing formData.values().toArray() , 1

        // Add the user ID to the beginning of the values array
        List<Object> valuesList = new ArrayList<>();
        valuesList.add(1);
        for (Object value : formData.values()) {
            valuesList.add(value);
        }

        jdbcTemplate.update(sql.toString(), valuesList.toArray());
    }

    // method to get all form data
    public List<Map<String, Object>> getFormData(Long formId) {
        String sql = "SELECT * FROM form_" + formId;
        return jdbcTemplate.queryForList(sql);
    }


    public List<Map<String, Object>> getFormFields(Long formId) {
        String sql = "SELECT q.id, q.text, q.type, q.data_type " +
                     "FROM " +
                     "page p "+
                     "JOIN question q ON p.id = q.page_id" +
                     " WHERE p.form_id =  " + formId;

        return jdbcTemplate.queryForList(sql);
    }

}


