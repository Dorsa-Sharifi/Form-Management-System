package org.example.backend.dto;

public record GoogleLoginRequest(String code) {
    // Constructor
}