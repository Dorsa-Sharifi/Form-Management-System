package org.example.backend.dto;

public record SignupResponse(String token) {
}
